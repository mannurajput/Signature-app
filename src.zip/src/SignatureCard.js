import React from 'react';
import { FaTrashAlt, FaEdit, FaDownload } from 'react-icons/fa';
import { Link } from 'react-router-dom';
const SignatureCard = ({ signatureImage, onEdit, onDelete, onDownload }) => {
  return (
    <div className="bg-white overflow-hidden shadow-lg rounded-lg">
      <div className="px-4 py-5 sm:p-6">
        <img src={signatureImage} alt="Signature" className="w-full h-32 object-contain" />
        <div className="mt-4 flex justify-end space-x-2">
          <button
            onClick={onDownload}
            className="text-gray-400 hover:text-gray-500"
            title="Download"
          >
            <FaDownload className="h-5 w-5" />
          </button>
          <button
            onClick={onDelete}
            className="text-red-400 hover:text-red-500"
            title="Delete"
          >
            <FaTrashAlt className="h-5 w-5" />
          </button>
          <Link to="/">
          <button
            onClick={onEdit}
            className="text-green-400 hover:text-green-500"
            title="Edit"
          >
            <FaEdit className="h-5 w-5" />
          </button></Link>
        </div>
      </div>
    </div>
  );
};

export default SignatureCard;
