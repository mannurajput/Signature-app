import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import SignaturePad from './SignaturePad';
import SignatureCard from './SignatureCard';
import { HexColorPicker } from 'react-colorful';

const Home = ({ onSave, editSignature, pencilColor, setPencilColor, padColor, setPadColor, penColor, setPenColor }) => (
  <div className="container mx-auto p-4 flex flex-col md:flex-row justify-center items-start md:items-center gap-8">
    <div className="flex flex-col items-center">
      <h2 className="text-lg font-semibold mb-2">Pencil Colour</h2>
      <HexColorPicker color={penColor} onChange={setPenColor} style={{ width: '100px', height: '300px' }} />
    </div>
    <SignaturePad onSave={onSave} initialSignature={editSignature} backgroundColor={padColor} penColor={penColor} />
    <div className="flex flex-col items-center">
      <h2 className="text-lg font-semibold mb-2"> Pad Background</h2>
      <HexColorPicker color={padColor} onChange={setPadColor} style={{ width: '100px', height: '300px' }} />
    </div>
  </div>
);



const Signatures = ({ signatures, onEdit, onDelete, onDownload }) => (
  <div className="container mx-auto p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
    {signatures.map((signature, index) => (
      <SignatureCard
        key={index}
        signatureImage={signature}
        onEdit={() => onEdit(index)}
        onDelete={() => onDelete(index)}
        onDownload={() => onDownload(signature)}
      />
    ))}
  </div>
);

const App = () => {
  const [signatures, setSignatures] = useState([]);
  const [editSignature, setEditSignature] = useState(null);
  const [pencilColor, setPencilColor] = useState('#000000'); // Pencil color state
  const [padColor, setPadColor] = useState('#FFFFFF'); // Signature pad background color state
  const [penColor, setPenColor] = useState('#000000'); // Pen color state

  const handleSave = (signature) => {
    setSignatures([...signatures, signature]);
    setEditSignature(null);
  };

  const handleEdit = (index) => {
    setEditSignature(signatures[index]);
    setSignatures(signatures.filter((_, i) => i !== index));
  };

  const handleDelete = (index) => {
    setSignatures(signatures.filter((_, i) => i !== index));
  };

  const handleDownload = (signature) => {
    const link = document.createElement('a');
    link.href = signature;
    link.download = 'signature.png';
    link.click();
  };

  return (
    <Router>
      <div className="container mx-auto p-4">
        <nav className="mb-4">
          <Link to="/" className="text-blue-500 hover:text-blue-700 mr-4">
            Home
          </Link>
          <Link to="/signatures" className="text-blue-500 hover:text-blue-700">
            Signatures
          </Link>
        </nav>
        <Routes>
          <Route
            exact
            path="/"
            element={
              <Home
                onSave={handleSave}
                editSignature={editSignature}
                pencilColor={pencilColor}
                setPencilColor={setPencilColor}
                padColor={padColor}
                setPadColor={setPadColor}
                penColor={penColor}
                setPenColor={setPenColor}
              />
            }
          />
          <Route
            path="/signatures"
            element={
              <Signatures
                signatures={signatures}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onDownload={handleDownload}
              />
            }
          />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
