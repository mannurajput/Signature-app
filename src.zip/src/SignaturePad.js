import React, { useRef, useState, useEffect } from 'react';
import { IoPencilOutline, IoBrushOutline } from 'react-icons/io5';
import { CgErase } from 'react-icons/cg';
import { isDisabled } from '@testing-library/user-event/dist/utils';

const SignaturePad = ({ onSave, initialSignature, backgroundColor, penColor }) => {
  const canvasRef = useRef(null);
  const [tool, setTool] = useState('pencil'); // Default tool
  const [isDrawing, setIsDrawing] = useState(false);
  const [isDisabled, setIsDisabled] = useState(true);
  useEffect(() => {
    if (initialSignature) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0);
      };
      img.src = initialSignature;
    }
  }, [initialSignature]);

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const saveSignature = () => {
    setIsDisabled(true)

    const canvas = canvasRef.current;
    const signatureImage = canvas.toDataURL('image/png');
    onSave(signatureImage);
    clearCanvas();
  };

  const changeTool = (newTool) => {
    setTool(newTool);
  };

  const startDrawing = (e) => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.lineWidth = 2;
    ctx.strokeStyle = penColor;
    ctx.lineCap = 'round';

    if (tool === 'pencil') {
      ctx.globalCompositeOperation = 'source-over';
    } else if (tool === 'paintbrush') {
      ctx.globalCompositeOperation = 'source-over'; // Adjust as needed
      ctx.lineWidth = 5; // Thicker line for paintbrush
    } else if (tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.lineWidth = 10; // Adjust eraser size as needed
    }

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const endDrawing = () => {
    setIsDrawing(false);
    setIsDisabled(false)

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.closePath();
  };

  return (
    <div className="mt-4 flex flex-col items-center">
      <div className="flex space-x-4 mb-4">
        <button
          className={`p-2 rounded-full ${tool === 'pencil' ? 'bg-gray-300' : ''}`}
          onClick={() => changeTool('pencil')}
        >
          <IoPencilOutline className="h-6 w-6 text-gray-700" />
        </button>
        <button
          className={`p-2 rounded-full ${tool === 'paintbrush' ? 'bg-gray-300' : ''}`}
          onClick={() => changeTool('paintbrush')}
        >
          <IoBrushOutline className="h-6 w-6 text-gray-700" />
        </button>
        <button
          className={`p-2 rounded-full ${tool === 'eraser' ? 'bg-gray-300' : ''}`}
          onClick={() => changeTool('eraser')}
        >
          <CgErase className="h-6 w-6 text-gray-700" />
        </button>
      </div>
      <div className="relative">
        <canvas
          ref={canvasRef}
          className="border border-gray-300 shadow-lg rounded-lg"
          width="800"
          height="400"
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={endDrawing}
          onMouseOut={endDrawing}
          style={{ boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)', backgroundColor: backgroundColor }}
        ></canvas>
      </div>
      <div className="mt-4 flex items-center">
        <button
          className="ml-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          onClick={clearCanvas}
        >
          Clear
        </button>
        <button
          className={`ml-2 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${isDisabled ? 'bg-gray-400' : 'bg-green-600 hover:bg-green-700 focus:ring-green-500'
            } focus:outline-none focus:ring-2 focus:ring-offset-2`}
          onClick={saveSignature}
          disabled={isDisabled}
        >
          Save
        </button>

      </div>
    </div>
  );
};

export default SignaturePad;
